package com.example.demo.model;

import com.example.demo.entity.QuizEntity;

/**
 * クイズ取得と結果判定ロジックインターフェース
 * 
 * @author 藤田
 *
 */
public interface QuizService {

    /**
     * 出題クイズ情報取得(初期遷移時)
     * 
     * @return 出題クイズ情報
     */
    public QuizEntity getQuiz();

    /**
     * 出題クイズ情報取得(2回目以降)
     * 
     * @param quizId
     *            クイズID
     * @return 出題クイズ情報
     */
    public QuizEntity getQuiz(int quizId);

    /**
     * クイズの解答正誤判定
     * 
     * @param quizId
     *            クイズID
     * @param ans
     *            画面入力情報の解答
     * @return 正誤情報(正解:true、不正解:false)
     */
    public boolean judgeQuiz(int quizId, String ans);

}
