package com.example.demo.common;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * 定数クラス
 * 
 * @author 藤田
 *
 */
public class QuizConst {

    /**
     * 画面のhtml
     */
    public static final String HTML_QUIZ = "quiz";

    /**
     * 正解時の表示文言
     */
    public static final String CORRECT_MSG = "正解";

    /**
     * 不正解時の表示文言
     */
    public static final String INCORRECT_MSG = "不正解";

    /**
     * クイズ一覧
     */
    public static final Map<Integer, HashMap<String, String>> QUIZ_LIST;
    static {
        HashMap<Integer, HashMap<String, String>> map = new HashMap<>();
        map.put(1, new HashMap<String, String>() {
            {
                put("どんなに頼んでも、売ってくれない人のお仕事は？", "うらないし");
            }
        });
        map.put(2, new HashMap<String, String>() {
            {
                put("「ダイ二テン」ってどんな動物？", "いぬ");
            }
        });
        map.put(3, new HashMap<String, String>() {
            {
                put("笑っている人しかいないお店は？", "くすりや");
            }
        });

        QUIZ_LIST = Collections.unmodifiableMap(map);
    }

}
