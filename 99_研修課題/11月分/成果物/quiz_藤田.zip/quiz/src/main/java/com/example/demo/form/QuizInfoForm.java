package com.example.demo.form;

import lombok.Data;

/**
 * クイズ情報フォーム
 * 
 * @author 藤田
 *
 */
@Data
public class QuizInfoForm {

    /**
     * クイズID
     */
    private Integer quizId;

    /**
     * クイズ問題文
     */
    private String quizQuestion;

    /**
     * クイズの解答
     */
    private String quizAns;

}
