package com.example.demo.entity;

import lombok.Data;

/**
 * クイズ情報Entity
 * 
 * @author 藤田
 *
 */
@Data
public class QuizQuestionEntity {

    /**
     * クイズID
     */
    private Integer quizId;

    /**
     * クイズ問題文
     */
    private String quizQuestion;

    /**
     * クイズの解答
     */
    private String quizAns;

}
