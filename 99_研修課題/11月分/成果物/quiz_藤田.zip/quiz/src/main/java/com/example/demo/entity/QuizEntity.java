package com.example.demo.entity;

import lombok.Data;

/**
 * クイズ情報取得結果Entity
 * 
 * @author 藤田
 *
 */
@Data
public class QuizEntity {

    /**
     * クイズ情報
     */
    private QuizQuestionEntity quizInfo;
    
    /**
     * クイズの解答の正解フラグ
     */
    private boolean isCorrect;

    

}
