package com.example.demo.form;

import lombok.Data;

/**
 * クイズ画面フォーム
 * 
 * @author 藤田
 *
 */
@Data
public class QuizForm {

    /**
     * クイズ情報フォーム
     */
    private QuizInfoForm quizInfoForm;

    /**
     * クイズ出題画面フラグ
     */
    private boolean isQuizDisplay;

    /**
     * 正誤判定メッセージ
     */
    private String resultMsg;

}
