package com.example.demo.controller;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.common.QuizConst;
import com.example.demo.entity.QuizEntity;
import com.example.demo.form.QuizForm;
import com.example.demo.form.QuizInfoForm;
import com.example.demo.model.QuizService;

/**
 * クイズ画面遷移コントローラ
 * 
 * @author 藤田
 *
 */
@Controller
@RequestMapping("/sampleQuestion")
public class QuizController {

    /**
     * サービスクラス
     */
    @Autowired
    private QuizService service;

    /**
     * クイズチャレンジ画面遷移
     * 
     * @param model
     *            Model
     * @param inputForm
     *            画面情報
     * @return クイズチャレンジ画面
     */
    @RequestMapping
    public String dispQuiz(Model model, QuizForm inputForm) {

        // クイズ取得結果を保持するEntity
        QuizEntity entity = new QuizEntity();
        // 画面に渡す情報を保持するForm
        QuizForm quizForm = new QuizForm();

        // クイズ情報取得
        if (Objects.nonNull(inputForm.getQuizInfoForm())) {
            // 2回目以降の遷移時は前回と異なる問題出題
            entity = this.service.getQuiz(inputForm.getQuizInfoForm().getQuizId());

        } else {
            // 初期遷移時はどれか一つ出題
            entity = this.service.getQuiz();
        }

        // 画面に送るフォーム情報セット
        QuizInfoForm quizInfoForm = new QuizInfoForm();
        quizInfoForm.setQuizId(entity.getQuizInfo().getQuizId());
        quizInfoForm.setQuizQuestion(entity.getQuizInfo().getQuizQuestion());
        quizForm.setQuizInfoForm(quizInfoForm);
        quizForm.setQuizDisplay(true);

        model.addAttribute("form", quizForm);

        return QuizConst.HTML_QUIZ;
    }

    /**
     * クイズ結果表示画面遷移
     * 
     * @param model
     *            Model
     * @param inputForm
     *            画面情報
     * @return クイズ結果表示画面
     */
    @RequestMapping("/result")
    public String dispResult(Model model, QuizForm inputForm) {

        // 画面に渡す情報を保持するForm
        QuizForm quizForm = new QuizForm();

        // クイズの正誤判定
        if (this.service.judgeQuiz(inputForm.getQuizInfoForm().getQuizId(), inputForm.getQuizInfoForm().getQuizAns())) {
            // 正解の場合のメッセージ設定
            quizForm.setResultMsg(QuizConst.CORRECT_MSG);
        } else {
            // 不正解の場合のメッセージ設定
            quizForm.setResultMsg(QuizConst.INCORRECT_MSG);
        }

        // 画面に送るフォーム情報セット
        QuizInfoForm quizInfoForm = new QuizInfoForm();
        quizInfoForm.setQuizId(inputForm.getQuizInfoForm().getQuizId());
        quizInfoForm.setQuizAns(inputForm.getQuizInfoForm().getQuizAns());
        quizForm.setQuizInfoForm(quizInfoForm);
        quizForm.setQuizDisplay(false);

        model.addAttribute("form", quizForm);

        return QuizConst.HTML_QUIZ;
    }

}
