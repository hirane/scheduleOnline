package com.example.demo.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Random;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.example.demo.common.QuizConst;
import com.example.demo.entity.QuizEntity;
import com.example.demo.entity.QuizQuestionEntity;

/**
 * クイズ取得と結果判定ロジック
 * 
 * @author 藤田
 *
 */
@Service
public class QuizServiceImplements implements QuizService {

    /**
     * 出題クイズ情報取得(初期遷移時)
     */
    public QuizEntity getQuiz() {

        // 返却用オブジェクト生成
        QuizEntity resultEntity = new QuizEntity();

        // クイズ一覧取得結果保持用リスト
        // クイズID取得
        List<QuizQuestionEntity> quizList = this.getQuizId(null);

        // 問題と解答をセット
        this.setQuizInfo(quizList);

        // 取得結果セット
        if (ObjectUtils.isEmpty(quizList)) {
            // 取得結果無しの場合、空データ返却
            resultEntity.setQuizInfo(new QuizQuestionEntity());
        } else {
            // データ取得できた場合、取得結果からランダムに1つのクイズを選ぶ
            resultEntity.setQuizInfo(quizList.get(new Random()
                .nextInt(CollectionUtils.size(quizList))));
        }

        return resultEntity;
    }

    /**
     * 出題クイズ情報取得(2回目以降)
     */
    public QuizEntity getQuiz(int quizId) {

        // 返却用オブジェクト生成
        QuizEntity resultEntity = new QuizEntity();

        // クイズ一覧取得結果保持用リスト
        // 直前のクイズを除いてクイズID取得
        List<QuizQuestionEntity> quizList = this.getQuizId(quizId);

        // 問題と解答をセット
        this.setQuizInfo(quizList);

        // 取得結果セット
        if (ObjectUtils.isNotEmpty(quizList)) {
            // データ取得できた場合、取得結果からランダムに1つのクイズを選ぶ
            resultEntity.setQuizInfo(quizList.get(new Random()
                .nextInt(CollectionUtils.size(quizList))));

            return resultEntity;
        }

        // 取得結果無しの場合、直前のクイズが存在するかを検索して返却
        return this.getPreviousQuiz(quizId);
    }

    /**
     * クイズの解答正誤判定
     */
    public boolean judgeQuiz(int quizId, String ans) {

        // 不正解でフラグ初期化
        boolean isCorrect = false;

        // クイズIDに対応する解答を取得
        Object[] gotAns = QuizConst.QUIZ_LIST.get(quizId).values().toArray();
        // 取得した解答の最後の要素と画面入力の解答を比較(1つのキーに対して複数のマップが定義された場合を考慮)
        if (StringUtils.equals(Objects.toString(gotAns[gotAns.length - 1]), ans)) {
            // 正解の場合はフラグ更新
            isCorrect = true;
        }
        return isCorrect;
    }

    /**
     * クイズIDを取得してセット
     * 
     * @param inputQuizId
     *            直前の問題のクイズID
     * @return クイズIDをセットしたEntityリスト
     */
    private List<QuizQuestionEntity> getQuizId(Integer inputQuizId) {

        // クイズ一覧取得結果保持用リスト
        List<QuizQuestionEntity> quizList = new ArrayList<>();

        // クイズIDを取得
        for (Integer quizId : QuizConst.QUIZ_LIST.keySet()) {

            // 直前のクイズIDと同じ場合はスキップ
            if (Objects.nonNull(inputQuizId) && inputQuizId == quizId) {
                continue;
            }

            QuizQuestionEntity quizEntity = new QuizQuestionEntity();
            quizEntity.setQuizId(quizId);
            quizList.add(quizEntity);
        }

        return quizList;
    }

    /**
     * クイズの問題と解答をセット
     * 
     * @param quizList
     *            クイズIDをセットしたEntityリスト
     */
    private void setQuizInfo(List<QuizQuestionEntity> quizList) {

        // クイズIDと対応する問題と解答をセット
        for (QuizQuestionEntity entity : quizList) {
            for (Entry<String, String> entry : QuizConst.QUIZ_LIST.get(entity.getQuizId()).entrySet()) {
                entity.setQuizQuestion(entry.getKey());
                entity.setQuizAns(entry.getValue());
            }
        }
    }

    /**
     * 出題するクイズを選択(直前と同じ問題情報取得)
     * 
     * @param quizId
     *            クイズID
     * @return 出題クイズ情報
     */
    private QuizEntity getPreviousQuiz(int quizId) {

        // 返却用オブジェクト生成
        QuizEntity resultEntity = new QuizEntity();

        // クイズが存在するか
        if (QuizConst.QUIZ_LIST.containsKey(quizId)) {

            // 存在する場合は直前のクイズと同じクイズを返却
            QuizQuestionEntity QuestionEntity = new QuizQuestionEntity();
            QuestionEntity.setQuizId(quizId);
            for (Entry<String, String> entry : QuizConst.QUIZ_LIST.get(quizId).entrySet()) {
                QuestionEntity.setQuizQuestion(entry.getKey());
                QuestionEntity.setQuizAns(entry.getValue());
            }

            resultEntity.setQuizInfo(QuestionEntity);

        } else {

            // 存在しない場合は空のEntity返却
            resultEntity.setQuizInfo(new QuizQuestionEntity());
        }

        return resultEntity;
    }

}
