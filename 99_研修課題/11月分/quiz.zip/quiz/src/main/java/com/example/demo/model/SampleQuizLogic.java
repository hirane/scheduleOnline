package com.example.demo.model;

import java.util.Random;

/**
 *
 * クイズ処理用ロジック
 * 
 * @author hirane
 *
 */
public class SampleQuizLogic {

	/**
	 * ランダムに問題番号をする
	 * 
	 * @param questionMaxNum 問題数
	 * @return 問題番号
	 */
	public int getQuestionNum(int questionMaxNum) {
		Random random = new Random();
		int randomValue = random.nextInt(questionMaxNum);
		return randomValue;
	}

	/**
	 * 引数の問題番号に応じて、問題文を返却する
	 * 
	 * @param questionNum 問題番号
	 * @return 問題分
	 */
	public String getQuestion(int questionNum) {
		if (questionNum == 0) {
			return "どんなに頼んでも、売ってくれない人のお仕事は";
		} else if (questionNum == 1) {
			return "「ダイ二テン」ってどんな動物？";
		} else if (questionNum == 2) {
			return "笑っている人しかいないお店は？";
		} else {
			return "エラーが発生しました";
		}
	}

	/**
	 * 引数の問題番号に応じて、答えと一致しているか確認を行う
	 * 
	 * @param questionNum 問題番号
	 * @param answer      解答
	 * @return 結果 true=正解 false=不正解
	 */
	public boolean getAnswer(int questionNum, String answer) {
		if (questionNum == 0) {
			return "うらないし".equals(answer);
		} else if (questionNum == 1) {
			return "いぬ".equals(answer);
		} else if (questionNum == 2) {
			return "くすりや".equals(answer);
		} else {
			return false;
		}
	}

}
