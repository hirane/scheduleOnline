package com.example.demo.controller;

import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.SampleQuizLogic;

/**
 * 
 * 画面処理用ロジック
 * 
 * @author hirane
 *
 */
@Controller
public class SampleQuizController {

	// 問題数
	public static final int questionMaxNum = 3;

	/**
	 * 
	 * 問題画面用ロジック
	 * 
	 * @param mav 画面への連携情報
	 * @return 画面遷移情報
	 */
	@RequestMapping(path = "/sampleQuestion", method = { GET, POST })
	private ModelAndView sampleQuestion(ModelAndView mav) {
		mav.setViewName("sampleQuestion");
		SampleQuizLogic quizLogic = new SampleQuizLogic();
		int questionNum = quizLogic.getQuestionNum(questionMaxNum);

		mav.addObject("question", quizLogic.getQuestion(questionNum));
		mav.addObject("questionNum", String.valueOf(questionNum));

		return mav;

	}

	/**
	 * 結果画面用ロジック
	 * 
	 * @param answer      解答
	 * @param questionNum 問題番号
	 * @param mav         画面への連携情報
	 * @return 画面遷移情報
	 */
	@RequestMapping(path = "/sampleAnswer", method = { GET, POST })
	private ModelAndView sampleAnswer(@RequestParam("answer") String answer,
			@RequestParam("questionNum") String questionNum, ModelAndView mav) {
		mav.setViewName("sampleAnswer");
		mav.addObject("answer", answer);
		SampleQuizLogic quizLogic = new SampleQuizLogic();

		System.out.println(questionNum);
		String result = "不正解";
		if (quizLogic.getAnswer(Integer.parseInt(questionNum), answer)) {
			result = "正解";
		}
		mav.addObject("result", result);
		return mav;
	}
}